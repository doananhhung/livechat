declare module "mermaid/dist/mermaid.esm.mjs" {
  import type { Mermaid } from "mermaid";
  const mermaid: Mermaid;
  export default mermaid;
}
